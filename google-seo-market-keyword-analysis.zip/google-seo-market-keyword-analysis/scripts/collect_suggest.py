#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
多平台搜索联想词采集器 —— 谷歌SEO市场和关键词分析 skill

采集 Google / YouTube / Bing / Amazon / DuckDuckGo / Reddit 的真实联想词，
输出结构化 JSON，供后续归族、打分、建表使用。

用法：
  # 0) 先探测哪些平台在当前网络下可达（决定要不要代理）
  python collect_suggest.py --probe

  # 1) 有代理：完整采集
  python collect_suggest.py --seed "silicone water bottle" --market US --lang en \
      --platforms google,amazon,youtube,ddg,reddit \
      --proxy "http://127.0.0.1:7890" --alphabet --modifiers \
      --out keywords_raw.json

  # 2) 无代理：只跑 Amazon（通常可直连）
  python collect_suggest.py --seed "silicone water bottle" --platforms amazon \
      --out keywords_raw.json

说明：
  - 仅依赖标准库。socks5 代理需要 `pip install requests pysocks`，否则请用 http 代理。
  - 单个平台/单条查询失败不会中断整体流程，错误汇总到 JSON 的 errors 字段。
"""

import argparse
import gzip
import json
import random
import re
import ssl
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime

# ---------------------------------------------------------------- 平台配置

MARKET_MAP = {
    # market -> (gl, hl_default, amazon_mid, amazon_host, bing_mkt)
    "US": ("us", "en", "ATVPDKIKX0DER", "completion.amazon.com", "en-US"),
    "UK": ("uk", "en", "A1F83G8C2ARO7P", "completion.amazon.co.uk", "en-GB"),
    "GB": ("uk", "en", "A1F83G8C2ARO7P", "completion.amazon.co.uk", "en-GB"),
    "DE": ("de", "de", "A1PA6795UKMFR9", "completion.amazon.de", "de-DE"),
    "FR": ("fr", "fr", "A13V1IB3VIYZZH", "completion.amazon.fr", "fr-FR"),
    "IT": ("it", "it", "APJ6JRA9NG5V4", "completion.amazon.it", "it-IT"),
    "ES": ("es", "es", "A1RKKUPIHCS9HS", "completion.amazon.es", "es-ES"),
    "CA": ("ca", "en", "A2EUQ1WTGCTBG2", "completion.amazon.ca", "en-CA"),
    "AU": ("au", "en", "A39IBJ37TRP1C6", "completion.amazon.com.au", "en-AU"),
    "JP": ("jp", "ja", "A1VC38T7YXB528", "completion.amazon.co.jp", "ja-JP"),
    "IN": ("in", "en", "A21TJRUUN4KGV", "completion.amazon.in", "en-IN"),
    "MX": ("mx", "es", "A1AM78C64UM0Y8", "completion.amazon.com.mx", "es-MX"),
    "AE": ("ae", "en", "A2VIGQ35RCS4UG", "completion.amazon.ae", "en-AE"),
    "GLOBAL": ("us", "en", "ATVPDKIKX0DER", "completion.amazon.com", "en-US"),
}

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36")

MODIFIERS = [
    "how", "what", "why", "when", "where", "which", "is", "are", "can", "does",
    "best", "top", "vs", "versus", "for", "with", "without",
    "cheap", "price", "buy", "near me",
    "wholesale", "manufacturer", "supplier", "factory", "custom", "oem",
    "private label", "review", "alternative", "bulk",
]


# ---------------------------------------------------------------- HTTP 层

class Fetcher:
    def __init__(self, proxy=None, timeout=15, retries=2):
        self.timeout = timeout
        self.proxy = proxy
        self.default_retries = retries
        self.ctx = ssl.create_default_context()
        self.ctx.check_hostname = False
        self.ctx.verify_mode = ssl.CERT_NONE
        self._opener = self._build_opener(proxy)

    def _build_opener(self, proxy):
        handlers = []
        if proxy:
            if proxy.lower().startswith("socks"):
                # socks 需要 requests+pysocks；这里给明确提示而不是静默失败
                raise SystemExit(
                    "socks5 代理需要额外依赖，请先执行：\n"
                    "  pip install requests pysocks\n"
                    "或改用 http 代理，例如 http://127.0.0.1:7890"
                )
            handlers.append(urllib.request.ProxyHandler({"http": proxy, "https": proxy}))
        else:
            handlers.append(urllib.request.ProxyHandler({}))
        handlers.append(urllib.request.HTTPSHandler(context=self.ctx))
        return urllib.request.build_opener(*handlers)

    def get(self, url, retries=None):
        if retries is None:
            retries = self.default_retries
        last = None
        for attempt in range(retries + 1):
            try:
                req = urllib.request.Request(url, headers={
                    "User-Agent": UA,
                    "Accept": "*/*",
                    "Accept-Language": "en-US,en;q=0.9",
                    "Accept-Encoding": "gzip, deflate",
                })
                with self._opener.open(req, timeout=self.timeout) as r:
                    raw = r.read()
                    if r.headers.get("Content-Encoding") == "gzip":
                        raw = gzip.decompress(raw)
                    return raw.decode("utf-8", errors="replace")
            except urllib.error.HTTPError as e:
                last = f"HTTP {e.code}"
                if e.code in (429, 500, 502, 503, 504) and attempt < retries:
                    time.sleep(1.5 * (attempt + 1))
                    continue
                raise RuntimeError(last)
            except Exception as e:
                last = f"{type(e).__name__}: {str(e)[:120]}"
                if attempt < retries:
                    time.sleep(1.5 * (attempt + 1))
                    continue
                raise RuntimeError(last)
        raise RuntimeError(last or "unknown")


# ---------------------------------------------------------------- 各平台采集

def _parse_jsonpish(text):
    """Google/Bing 返回的是 JSON 数组，但可能是非标准编码。"""
    text = text.strip()
    if not text:
        return []
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        return []
    if isinstance(data, list) and len(data) >= 2 and isinstance(data[1], list):
        return [str(x).strip() for x in data[1] if str(x).strip()]
    return []


def suggest_google(f, q, gl, hl):
    url = ("https://suggestqueries.google.com/complete/search"
           f"?client=firefox&hl={hl}&gl={gl}&q={urllib.parse.quote(q)}")
    return _parse_jsonpish(f.get(url))


def suggest_youtube(f, q, gl, hl):
    url = ("https://suggestqueries.google.com/complete/search"
           f"?client=firefox&ds=youtube&hl={hl}&gl={gl}&q={urllib.parse.quote(q)}")
    return _parse_jsonpish(f.get(url))


def suggest_bing(f, q, mkt):
    url = f"https://api.bing.com/osjson.aspx?query={urllib.parse.quote(q)}&market={mkt}"
    return _parse_jsonpish(f.get(url))


def suggest_amazon(f, q, mid, host):
    url = (f"https://{host}/api/2017/suggestions"
           f"?mid={mid}&alias=aps&prefix={urllib.parse.quote(q)}"
           f"&fresh=0&suggestion-type=WIDGET")
    text = f.get(url)
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        return []
    out = []
    for item in data.get("suggestions", []):
        v = (item.get("value") or "").strip()
        if v:
            out.append(v)
    return out


def suggest_ddg(f, q):
    url = f"https://duckduckgo.com/ac/?q={urllib.parse.quote(q)}&type=list"
    text = f.get(url)
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        return []
    out = []
    if isinstance(data, list):
        for item in data:
            if isinstance(item, dict) and item.get("phrase"):
                out.append(str(item["phrase"]).strip())
            elif isinstance(item, str):
                out.append(item.strip())
    return [x for x in out if x]


def search_reddit(f, q, limit=25):
    """Reddit 返回讨论帖，不是关键词。用于话题/痛点挖掘。"""
    url = (f"https://www.reddit.com/search.json?q={urllib.parse.quote(q)}"
           f"&limit={limit}&sort=relevance&t=year")
    text = f.get(url)
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        return []
    posts = []
    for child in data.get("data", {}).get("children", []):
        d = child.get("data", {})
        title = (d.get("title") or "").strip()
        if not title:
            continue
        posts.append({
            "title": title,
            "subreddit": d.get("subreddit"),
            "score": d.get("score", 0),
            "num_comments": d.get("num_comments", 0),
            "url": "https://www.reddit.com" + (d.get("permalink") or ""),
        })
    return posts


PLATFORM_LABEL = {
    "google": "Google", "youtube": "YouTube", "bing": "Bing",
    "amazon": "Amazon", "ddg": "DuckDuckGo", "reddit": "Reddit",
}


# ---------------------------------------------------------------- 主流程

def normalize(s):
    return re.sub(r"\s+", " ", s.strip().lower())


def build_queries(seeds, alphabet=False, modifiers=False):
    qs = []
    for s in seeds:
        qs.append(s)
        if alphabet:
            for c in "abcdefghijklmnopqrstuvwxyz":
                qs.append(f"{s} {c}")
        if modifiers:
            for m in MODIFIERS:
                qs.append(f"{m} {s}")
    # 去重保序
    seen, out = set(), []
    for q in qs:
        k = normalize(q)
        if k not in seen:
            seen.add(k)
            out.append(q)
    return out


def probe(proxy, gl, hl, mid, ahost, mkt):
    """探测各平台在当前网络下是否可达（快速模式：5s 超时、不重试）。"""
    fetcher = Fetcher(proxy=proxy, timeout=5, retries=0)
    tests = [
        ("google", lambda: suggest_google(fetcher, "water bottle", gl, hl)),
        ("youtube", lambda: suggest_youtube(fetcher, "water bottle", gl, hl)),
        ("bing", lambda: suggest_bing(fetcher, "water bottle", mkt)),
        ("amazon", lambda: suggest_amazon(fetcher, "water bottle", mid, ahost)),
        ("ddg", lambda: suggest_ddg(fetcher, "water bottle")),
        ("reddit", lambda: search_reddit(fetcher, "water bottle", limit=2)),
    ]
    print(f"{'平台':<12} {'状态':<8} 说明", flush=True)
    print("-" * 62, flush=True)
    ok = []
    for name, fn in tests:
        try:
            res = fn()
            if res:
                print(f"{PLATFORM_LABEL[name]:<12} {'可达':<8} 返回 {len(res)} 条", flush=True)
                ok.append(name)
            else:
                print(f"{PLATFORM_LABEL[name]:<12} {'空结果':<8} 连通但无数据（可能需要换 market 或代理）", flush=True)
        except Exception as e:
            print(f"{PLATFORM_LABEL[name]:<12} {'不可达':<8} {str(e)[:70]}", flush=True)
    print("-" * 62, flush=True)
    if ok:
        print(f"建议使用：--platforms {','.join(ok)}", flush=True)
    else:
        print("全部不可达 —— 请提供 http 代理，或改用 WebSearch 通道。", flush=True)
    return ok


def main():
    ap = argparse.ArgumentParser(
        description="多平台搜索联想词采集器（谷歌SEO市场和关键词分析）")
    ap.add_argument("--seed", action="append", default=[],
                    help="种子词，可重复传或逗号分隔")
    ap.add_argument("--market", default="US", help="市场代码，如 US/UK/DE/AU/JP/GLOBAL")
    ap.add_argument("--lang", default=None, help="语言代码，默认按市场推断")
    ap.add_argument("--platforms", default="google,amazon",
                    help="平台列表，逗号分隔：google,youtube,bing,amazon,ddg,reddit")
    ap.add_argument("--proxy", default=None, help="http://ip:port 或 socks5://...")
    ap.add_argument("--alphabet", action="store_true", help="开启 a-z 字母扩展")
    ap.add_argument("--modifiers", action="store_true", help="开启疑问/比较/购买修饰词扩展")
    ap.add_argument("--delay", type=float, default=0.6, help="每次请求间隔秒数，默认 0.6")
    ap.add_argument("--out", default="keywords_raw.json", help="输出 JSON 路径")
    ap.add_argument("--probe", action="store_true", help="只探测各平台连通性")
    args = ap.parse_args()

    market = args.market.upper()
    gl, hl_def, mid, ahost, mkt = MARKET_MAP.get(market, MARKET_MAP["US"])
    hl = args.lang or hl_def

    if args.probe:
        try:
            probe(args.proxy, gl, hl, mid, ahost, mkt)
        except SystemExit as e:
            print(str(e), file=sys.stderr)
            sys.exit(2)
        return

    try:
        fetcher = Fetcher(proxy=args.proxy)
    except SystemExit as e:
        print(str(e), file=sys.stderr)
        sys.exit(2)

    seeds = []
    for s in args.seed:
        seeds.extend([x.strip() for x in s.split(",") if x.strip()])
    if not seeds:
        print("错误：至少需要一个 --seed", file=sys.stderr)
        sys.exit(2)

    platforms = [p.strip().lower() for p in args.platforms.split(",") if p.strip()]
    queries = build_queries(seeds, args.alphabet, args.modifiers)

    print(f"市场: {market}  语言: {hl}  种子: {len(seeds)}  查询数: {len(queries)}  "
          f"平台: {','.join(platforms)}", file=sys.stderr)
    if args.proxy:
        print(f"代理: 已启用", file=sys.stderr)

    keywords = {}
    discussions = {}
    errors = []
    total = len(queries) * len(platforms)
    done = 0

    def add_kw(text, platform, seed):
        k = normalize(text)
        if not k or len(k) < 3:
            return
        rec = keywords.setdefault(k, {"text": text.strip(), "sources": [], "seeds": [], "hits": 0})
        if platform not in rec["sources"]:
            rec["sources"].append(platform)
        if seed not in rec["seeds"]:
            rec["seeds"].append(seed)
        rec["hits"] += 1

    for q in queries:
        for pf in platforms:
            done += 1
            if done % 20 == 0 or done == total:
                print(f"  进度 {done}/{total}", file=sys.stderr)
            try:
                if pf == "google":
                    res = suggest_google(fetcher, q, gl, hl)
                elif pf == "youtube":
                    res = suggest_youtube(fetcher, q, gl, hl)
                elif pf == "bing":
                    res = suggest_bing(fetcher, q, mkt)
                elif pf == "amazon":
                    res = suggest_amazon(fetcher, q, mid, ahost)
                elif pf == "ddg":
                    res = suggest_ddg(fetcher, q)
                elif pf == "reddit":
                    posts = search_reddit(fetcher, q)
                    bucket = discussions.setdefault("reddit", [])
                    known = {p["url"] for p in bucket}
                    for p in posts:
                        if p["url"] not in known:
                            bucket.append(p)
                            known.add(p["url"])
                    res = []
                else:
                    errors.append({"platform": pf, "query": q, "error": "未知平台"})
                    continue

                for item in res:
                    add_kw(item, pf, q)

            except Exception as e:
                errors.append({"platform": pf, "query": q, "error": str(e)[:160]})

            if args.delay:
                time.sleep(args.delay * random.uniform(0.6, 1.4))

    payload = {
        "meta": {
            "seeds": seeds,
            "market": market,
            "lang": hl,
            "platforms": platforms,
            "proxy": bool(args.proxy),
            "alphabet": args.alphabet,
            "modifiers": args.modifiers,
            "query_count": len(queries),
            "generated_at": datetime.now().isoformat(timespec="seconds"),
        },
        "keywords": keywords,
        "discussions": discussions,
        "errors": errors,
    }

    with open(args.out, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, ensure_ascii=False, indent=2)

    print(f"\n完成：{len(keywords)} 个去重关键词，"
          f"{sum(len(v) for v in discussions.values())} 条讨论帖，"
          f"{len(errors)} 条错误 → {args.out}", file=sys.stderr)
    if errors:
        by_pf = {}
        for e in errors:
            by_pf[e["platform"]] = by_pf.get(e["platform"], 0) + 1
        print("失败分布：" + ", ".join(f"{k}×{v}" for k, v in by_pf.items()), file=sys.stderr)


if __name__ == "__main__":
    main()
