#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
关键词 Excel 生成器 —— 谷歌SEO市场和关键词分析 skill

把「采集结果 + 人工/模型标注」转成可直接交付的 xlsx。

两种用法：
  1) 正式产出（推荐）：先由模型完成归族/意图/优先级标注，写 annotations.json，
     再建表。这样 Excel 里是有判断的作战地图，不是原始词堆。
       python build_excel.py --annotations annotations.json --out 关键词分析.xlsx

  2) 快速预览：只有采集结果时，建一个「候选词池」表，语义字段留空待填。
       python build_excel.py --input keywords_raw.json --out 候选词池.xlsx

annotations.json 结构见 references/output-spec.md
"""

import argparse
import json
import os
import sys
from datetime import datetime

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

# ---------------------------------------------------------------- 样式常量

FONT_NAME = "微软雅黑"
C_HEADER_BG = "1F3864"
C_HEADER_FG = "FFFFFF"
C_BAND = "F2F5FA"
C_BORDER = "D9DEE8"

PRIORITY_STYLE = {
    "A": ("C6EFCE", "006100"),
    "B": ("FFEB9C", "9C6500"),
    "C": ("E7E6E6", "3F3F3F"),
    "D": ("FFC7CE", "9C0006"),
}

THIN = Side(style="thin", color=C_BORDER)
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)


def style_header(ws, row, ncols, height=30):
    for c in range(1, ncols + 1):
        cell = ws.cell(row=row, column=c)
        cell.font = Font(name=FONT_NAME, bold=True, size=10.5, color=C_HEADER_FG)
        cell.fill = PatternFill("solid", fgColor=C_HEADER_BG)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = BORDER
    ws.row_dimensions[row].height = height


def style_body(ws, first_row, last_row, ncols, widths, wrap_cols=()):
    for r in range(first_row, last_row + 1):
        for c in range(1, ncols + 1):
            cell = ws.cell(row=r, column=c)
            cell.font = Font(name=FONT_NAME, size=10)
            cell.border = BORDER
            wrap = c in wrap_cols
            cell.alignment = Alignment(
                horizontal="left" if wrap else "center",
                vertical="center",
                wrap_text=wrap,
            )
            if (r - first_row) % 2 == 1:
                cell.fill = PatternFill("solid", fgColor=C_BAND)
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w


def set_title(ws, text, ncols, subtitle=None):
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncols)
    cell = ws.cell(row=1, column=1, value=text)
    cell.font = Font(name=FONT_NAME, bold=True, size=15, color="1F3864")
    cell.alignment = Alignment(horizontal="left", vertical="center")
    ws.row_dimensions[1].height = 34
    if subtitle:
        ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=ncols)
        sc = ws.cell(row=2, column=1, value=subtitle)
        sc.font = Font(name=FONT_NAME, size=9, color="7F7F7F")
        sc.alignment = Alignment(horizontal="left", vertical="center")
        ws.row_dimensions[2].height = 20


# ---------------------------------------------------------------- 各工作表

def sheet_keywords(wb, ann):
    ws = wb.active
    ws.title = "关键词总表"
    headers = ["#", "关键词", "词族", "月搜索量(估算)", "量级中值", "KD",
               "搜索意图", "客群", "优先级", "处理建议", "备注"]
    ncols = len(headers)
    widths = [5, 42, 18, 17, 11, 7, 12, 9, 8, 30, 26]
    set_title(ws, "关键词总表", ncols,
              f"产品：{ann.get('product','-')}　市场：{ann.get('market','-')}　"
              f"共 {len(ann['keywords'])} 个关键词　搜索量为估算区间，非第三方精确值")

    hr = 4
    for i, h in enumerate(headers, start=1):
        ws.cell(row=hr, column=i, value=h)
    style_header(ws, hr, ncols)

    rows = ann["keywords"]
    for idx, kw in enumerate(rows, start=1):
        r = hr + idx
        vals = [
            idx,
            kw.get("keyword", ""),
            kw.get("family", ""),
            kw.get("volume", ""),
            kw.get("volume_mid", None),
            kw.get("kd", None),
            kw.get("intent", ""),
            kw.get("audience", ""),
            kw.get("priority", ""),
            kw.get("action", ""),
            kw.get("note", ""),
        ]
        for c, v in enumerate(vals, start=1):
            ws.cell(row=r, column=c, value=v)
        if isinstance(kw.get("volume_mid"), (int, float)):
            ws.cell(row=r, column=5).number_format = "#,##0"

    last = hr + len(rows)
    style_body(ws, hr + 1, last, ncols, widths, wrap_cols=(2, 10, 11))

    # 优先级配色
    for idx, kw in enumerate(rows, start=1):
        p = (kw.get("priority") or "").strip().upper()[:1]
        if p in PRIORITY_STYLE:
            bg, fg = PRIORITY_STYLE[p]
            cell = ws.cell(row=hr + idx, column=9)
            cell.fill = PatternFill("solid", fgColor=bg)
            cell.font = Font(name=FONT_NAME, size=10, bold=True, color=fg)

    ws.freeze_panes = f"A{hr+1}"
    if rows:
        ws.auto_filter.ref = f"A{hr}:{get_column_letter(ncols)}{last}"
    ws.sheet_view.showGridLines = False
    return ws, hr, last


def sheet_families(wb, ann, kw_hr, kw_last):
    ws = wb.create_sheet("词族汇总")
    headers = ["词族", "词数", "搜索量合计(中值)", "占比", "平均 KD", "A级词数", "说明"]
    ncols = len(headers)
    widths = [24, 9, 19, 10, 10, 10, 46]
    set_title(ws, "词族汇总", ncols,
              "本表数值由公式引用「关键词总表」，修改明细后自动更新")

    hr = 4
    for i, h in enumerate(headers, start=1):
        ws.cell(row=hr, column=i, value=h)
    style_header(ws, hr, ncols)

    desc_map = {f.get("family"): f.get("desc", "") for f in ann.get("families", [])}
    fams = []
    for kw in ann["keywords"]:
        f = kw.get("family") or "未归类"
        if f not in fams:
            fams.append(f)

    rng_f = f"'关键词总表'!$C${kw_hr+1}:$C${kw_last}"
    rng_v = f"'关键词总表'!$E${kw_hr+1}:$E${kw_last}"
    rng_k = f"'关键词总表'!$F${kw_hr+1}:$F${kw_last}"
    rng_p = f"'关键词总表'!$I${kw_hr+1}:$I${kw_last}"

    for idx, fam in enumerate(fams, start=1):
        r = hr + idx
        ws.cell(row=r, column=1, value=fam)
        ws.cell(row=r, column=2, value=f'=COUNTIF({rng_f},$A{r})')
        ws.cell(row=r, column=3, value=f'=SUMIF({rng_f},$A{r},{rng_v})')
        ws.cell(row=r, column=4, value=f'=IFERROR($C{r}/SUM($C${hr+1}:$C${hr+len(fams)}),0)')
        ws.cell(row=r, column=5, value=f'=IFERROR(AVERAGEIF({rng_f},$A{r},{rng_k}),"")')
        ws.cell(row=r, column=6, value=f'=COUNTIFS({rng_f},$A{r},{rng_p},"A")')
        ws.cell(row=r, column=7, value=desc_map.get(fam, ""))
        ws.cell(row=r, column=3).number_format = "#,##0"
        ws.cell(row=r, column=4).number_format = "0.0%"
        ws.cell(row=r, column=5).number_format = "0.0"

    tr = hr + len(fams) + 1
    ws.cell(row=tr, column=1, value="合计")
    ws.cell(row=tr, column=2, value=f'=SUM($B${hr+1}:$B${hr+len(fams)})')
    ws.cell(row=tr, column=3, value=f'=SUM($C${hr+1}:$C${hr+len(fams)})')
    ws.cell(row=tr, column=4, value=f'=SUM($D${hr+1}:$D${hr+len(fams)})')
    ws.cell(row=tr, column=6, value=f'=SUM($F${hr+1}:$F${hr+len(fams)})')
    ws.cell(row=tr, column=3).number_format = "#,##0"
    ws.cell(row=tr, column=4).number_format = "0.0%"
    for c in range(1, ncols + 1):
        cell = ws.cell(row=tr, column=c)
        cell.font = Font(name=FONT_NAME, size=10.5, bold=True)
        cell.fill = PatternFill("solid", fgColor="DDEBF7")
        cell.border = BORDER
        cell.alignment = Alignment(horizontal="center", vertical="center")

    style_body(ws, hr + 1, tr - 1, ncols, widths, wrap_cols=(7,))
    ws.freeze_panes = f"A{hr+1}"
    ws.sheet_view.showGridLines = False


def sheet_strategy(wb, ann, kw_hr, kw_last):
    ws = wb.create_sheet("优先级策略")
    headers = ["级别", "定义", "动作", "词数", "代表词"]
    ncols = len(headers)
    widths = [8, 34, 40, 8, 44]
    set_title(ws, "优先级策略", ncols, "A 立即做 / B 辅助 / C 观察 / D 不做")

    hr = 4
    for i, h in enumerate(headers, start=1):
        ws.cell(row=hr, column=i, value=h)
    style_header(ws, hr, ncols)

    rng_f = f"'关键词总表'!$C${kw_hr+1}:$C${kw_last}"
    rng_p = f"'关键词总表'!$I${kw_hr+1}:$I${kw_last}"
    rng_k = f"'关键词总表'!$B${kw_hr+1}:$B${kw_last}"

    strategy = ann.get("strategy") or []
    if not strategy:
        strategy = [
            {"level": "A", "rule": "中高量 + 低中 KD + 商业意图", "action": "立即写，排期前 3 个月"},
            {"level": "B", "rule": "高量高 KD，或中量中 KD", "action": "辅助文，蹭长尾"},
            {"level": "C", "rule": "泛词、KD 高、意图杂", "action": "只做观察，不投人力"},
            {"level": "D", "rule": "品牌词、无关词", "action": "明确不做"},
        ]

    for idx, s in enumerate(strategy, start=1):
        r = hr + idx
        lv = s.get("level", "").upper()[:1]
        ws.cell(row=r, column=1, value=lv)
        ws.cell(row=r, column=2, value=s.get("rule", ""))
        ws.cell(row=r, column=3, value=s.get("action", ""))
        ws.cell(row=r, column=4, value=f'=COUNTIF({rng_p},"{lv}")')
        reps = [kw.get("keyword", "") for kw in ann["keywords"]
                if (kw.get("priority") or "").upper().startswith(lv)][:4]
        ws.cell(row=r, column=5, value="；".join(reps))
        if lv in PRIORITY_STYLE:
            bg, fg = PRIORITY_STYLE[lv]
            cell = ws.cell(row=r, column=1)
            cell.fill = PatternFill("solid", fgColor=bg)
            cell.font = Font(name=FONT_NAME, size=11, bold=True, color=fg)

    last = hr + len(strategy)
    style_body(ws, hr + 1, last, ncols, widths, wrap_cols=(2, 3, 5))
    for idx, s in enumerate(strategy, start=1):
        lv = s.get("level", "").upper()[:1]
        if lv in PRIORITY_STYLE:
            bg, fg = PRIORITY_STYLE[lv]
            cell = ws.cell(row=hr + idx, column=1)
            cell.fill = PatternFill("solid", fgColor=bg)
            cell.font = Font(name=FONT_NAME, size=11, bold=True, color=fg)
    ws.sheet_view.showGridLines = False


def sheet_topics(wb, ann):
    topics = ann.get("topics") or []
    if not topics:
        return
    ws = wb.create_sheet("话题清单")
    headers = ["#", "话题", "来源", "用户痛点", "对应关键词", "内容形式", "优先级"]
    ncols = len(headers)
    widths = [5, 40, 16, 34, 30, 14, 9]
    set_title(ws, "话题清单", ncols, "话题来自真实社区讨论与 SERP，不是生造的标题")

    hr = 4
    for i, h in enumerate(headers, start=1):
        ws.cell(row=hr, column=i, value=h)
    style_header(ws, hr, ncols)

    for idx, t in enumerate(topics, start=1):
        r = hr + idx
        vals = [idx, t.get("topic", ""), t.get("source", ""), t.get("pain", ""),
                t.get("keywords", ""), t.get("format", ""), t.get("priority", "")]
        for c, v in enumerate(vals, start=1):
            ws.cell(row=r, column=c, value=v)

    last = hr + len(topics)
    style_body(ws, hr + 1, last, ncols, widths, wrap_cols=(2, 4, 5))
    for idx, t in enumerate(topics, start=1):
        p = (t.get("priority") or "").strip().upper()[:1]
        if p in PRIORITY_STYLE:
            bg, fg = PRIORITY_STYLE[p]
            cell = ws.cell(row=hr + idx, column=7)
            cell.fill = PatternFill("solid", fgColor=bg)
            cell.font = Font(name=FONT_NAME, size=10, bold=True, color=fg)
    ws.freeze_panes = f"A{hr+1}"
    ws.auto_filter.ref = f"A{hr}:{get_column_letter(ncols)}{last}"
    ws.sheet_view.showGridLines = False


def sheet_notes(wb, ann):
    ws = wb.create_sheet("数据说明")
    set_title(ws, "数据说明", 2, "交付前必读：数据从哪来、是什么性质、怎么用")

    meta = ann.get("meta", {}) or {}
    pairs = [
        ("产品 / 品类", ann.get("product", "-")),
        ("目标市场", ann.get("market", "-")),
        ("数据采集平台", "、".join(meta.get("platforms", [])) or "-"),
        ("采集通道", meta.get("channel", "-")),
        ("代理", meta.get("proxy", "-")),
        ("采集时间", meta.get("generated_at", datetime.now().strftime("%Y-%m-%d %H:%M"))),
        ("关键词总数", str(len(ann.get("keywords", [])))),
        ("", ""),
        ("搜索量性质", "估算区间，非 Ahrefs / Semrush 精确值。依据：联想词出现平台数与位次、"
                    "SERP 前 10 构成、同品类已知基准。用于排序与取舍，不用于对外报价。"),
        ("KD 性质", "启发式判断，依据 SERP 前 10 的站点类型（大站 / 平台页 / 品牌站 / 小站）"
                 "与内容深度，非第三方 KD 分数。"),
        ("优先级规则", "A=中高量+低中KD+商业意图；B=高量高KD或中量中KD；"
                   "C=泛词/高KD/意图杂；D=品牌词/无关词。"),
        ("B2B 提示", "manufacturer / supplier / wholesale / OEM / custom 类词月搜索量常仅 300–900，"
                  "但 KD 低、询盘质量高，制造商站点应给 A 级优先级。"),
        ("", ""),
        ("使用建议", "1) 先做 A 级词，一页打一个词族；2) 不同词族必须拆页；"
                 "3) 品牌词单列不做；4) 排期放在搜索高峰前 1–2 个月。"),
    ]

    r = 4
    for k, v in pairs:
        kc = ws.cell(row=r, column=1, value=k)
        vc = ws.cell(row=r, column=2, value=v)
        kc.font = Font(name=FONT_NAME, size=10, bold=True, color="1F3864")
        vc.font = Font(name=FONT_NAME, size=10)
        kc.alignment = Alignment(horizontal="left", vertical="top", wrap_text=True)
        vc.alignment = Alignment(horizontal="left", vertical="top", wrap_text=True)
        if k:
            kc.fill = PatternFill("solid", fgColor="F2F5FA")
        ws.row_dimensions[r].height = 22 if len(str(v)) < 40 else 48
        r += 1

    ws.column_dimensions["A"].width = 20
    ws.column_dimensions["B"].width = 100
    ws.sheet_view.showGridLines = False


# ---------------------------------------------------------------- 主流程

def from_raw(raw_path):
    """把采集原始 JSON 转成最小 annotations 结构。"""
    with open(raw_path, encoding="utf-8") as fh:
        raw = json.load(fh)
    kws = []
    for k, v in sorted(raw.get("keywords", {}).items(),
                       key=lambda x: -x[1].get("hits", 0)):
        kws.append({
            "keyword": v.get("text", k),
            "family": "",
            "volume": "",
            "volume_mid": None,
            "kd": None,
            "intent": "",
            "audience": "",
            "priority": "",
            "action": "",
            "note": f"来源：{','.join(v.get('sources', []))}；命中 {v.get('hits',0)} 次",
        })
    return {
        "product": ", ".join(raw.get("meta", {}).get("seeds", [])),
        "market": raw.get("meta", {}).get("market", ""),
        "keywords": kws,
        "families": [],
        "topics": [],
        "strategy": [],
        "meta": {
            "platforms": raw.get("meta", {}).get("platforms", []),
            "channel": "collect_suggest.py",
            "proxy": "已启用" if raw.get("meta", {}).get("proxy") else "未使用",
            "generated_at": raw.get("meta", {}).get("generated_at", ""),
        },
    }


def main():
    ap = argparse.ArgumentParser(description="关键词 Excel 生成器")
    ap.add_argument("--annotations", help="标注后的 JSON（推荐）")
    ap.add_argument("--input", help="collect_suggest.py 输出的原始 JSON")
    ap.add_argument("--out", default="关键词分析.xlsx", help="输出 xlsx 路径")
    args = ap.parse_args()

    if args.annotations:
        with open(args.annotations, encoding="utf-8") as fh:
            ann = json.load(fh)
        if not ann.get("keywords"):
            print("错误：annotations.json 里没有 keywords", file=sys.stderr)
            sys.exit(2)
    elif args.input:
        ann = from_raw(args.input)
    else:
        print("错误：需要 --annotations 或 --input", file=sys.stderr)
        sys.exit(2)

    wb = Workbook()
    ws1, hr, last = sheet_keywords(wb, ann)
    sheet_families(wb, ann, hr, last)
    sheet_strategy(wb, ann, hr, last)
    sheet_topics(wb, ann)
    sheet_notes(wb, ann)

    out_dir = os.path.dirname(os.path.abspath(args.out))
    if out_dir and not os.path.isdir(out_dir):
        os.makedirs(out_dir, exist_ok=True)
    wb.save(args.out)
    print(f"已生成：{args.out}（{len(ann['keywords'])} 个关键词，{len(wb.sheetnames)} 个工作表）")


if __name__ == "__main__":
    main()
