# 平台接口参考

各平台联想词接口的 URL、参数、返回格式与连通性实测记录。

**先跑探测，再决定通道**：

```bash
python scripts/collect_suggest.py --probe --market US
```

输出会直接告诉你哪些平台可达、建议用哪些平台。

---

## 一、连通性实测（2026-11，中国网络环境，无代理）

| 平台 | 状态 | 表现 | 结论 |
|---|---|---|---|
| **Amazon** | 可达 | 0.3s 返回 10 条 | 唯一可直连的主力平台，务必用上 |
| **Bing** | 可达 | 返回 25 条 | 可直连，是 Google 的最佳替代 |
| **Google** | 不可达 | `urlopen error timed out` | 需代理 |
| **YouTube** | 不可达 | 同上（同域 suggestqueries.google.com） | 需代理 |
| **DuckDuckGo** | 不可达 | 同上 | 需代理 |
| **Reddit** | 不可达 | 同上 | 需代理 |

> 关键结论：**没有代理时，Bing + Amazon 仍然能跑出足够好的结果**，不要因为 Google 不可达就放弃采集。
> 有代理时全部打开，Google 的字母扩展词覆盖面最广。

**注意**：Bing 接口对 User-Agent 和 Accept 头敏感。不带浏览器 UA 时会返回 `204 No Content`（空响应），带上后正常返回 25 条。脚本里已处理。

---

## 二、各平台接口明细

### 1. Google 联想词

```
GET https://suggestqueries.google.com/complete/search
    ?client=firefox
    &hl={lang}        # en / de / ja
    &gl={country}     # us / uk / de
    &q={keyword}
```

返回（JSON 数组，第 2 项是联想词列表）：

```json
["silicone water bottle", [
  "silicone water bottle with straw",
  "silicone water bottle 1 litre",
  "silicone water bottle bpa free"
]]
```

要点：

- `client=firefox` 返回最干净的 JSON；`client=chrome` 会带额外字段
- 编码可能是 ISO-8859-1，脚本按 utf-8 容错解码
- 加 `&ds=youtube` 就变成 YouTube 联想词，其余参数相同

### 2. YouTube 联想词

```
GET https://suggestqueries.google.com/complete/search
    ?client=firefox&ds=youtube&hl={lang}&gl={country}&q={keyword}
```

返回格式同 Google。适合找「教程 / 测评 / 开箱」类选题。

### 3. Bing 联想词

```
GET https://api.bing.com/osjson.aspx
    ?query={keyword}
    &market={mkt}     # en-US / en-GB / de-DE
```

返回格式同 Google（`["query", ["s1", "s2"]]`）。

要点：

- 必须带浏览器 UA，否则 `204`
- 联想词偏「完整查询句」，比 Google 更长尾，适合直接当文章标题参考
- 欧美 B2B 采购者用 Bing 的比例高于普通消费者，工业品类值得重点跑

### 4. Amazon 电商搜索词

```
GET https://{host}/api/2017/suggestions
    ?mid={marketplace_id}
    &alias=aps
    &prefix={keyword}
    &fresh=0
    &suggestion-type=WIDGET
```

返回：

```json
{
  "alias": "aps",
  "prefix": "silicone water bottle",
  "suggestions": [
    {"value": "silicone water bottle with straw", "type": "KEYWORD"},
    {"value": "silicone water bottle 1l", "type": "KEYWORD"}
  ]
}
```

站点与 `mid` 对照：

| 站点 | host | mid |
|---|---|---|
| 美国 | completion.amazon.com | `ATVPDKIKX0DER` |
| 英国 | completion.amazon.co.uk | `A1F83G8C2ARO7P` |
| 德国 | completion.amazon.de | `A1PA6795UKMFR9` |
| 法国 | completion.amazon.fr | `A13V1IB3VIYZZH` |
| 意大利 | completion.amazon.it | `APJ6JRA9NG5V4` |
| 西班牙 | completion.amazon.es | `A1RKKUPIHCS9HS` |
| 加拿大 | completion.amazon.ca | `A2EUQ1WTGCTBG2` |
| 澳洲 | completion.amazon.com.au | `A39IBJ37TRP1C6` |
| 日本 | completion.amazon.co.jp | `A1VC38T7YXB528` |
| 印度 | completion.amazon.in | `A21TJRUUN4KGV` |
| 墨西哥 | completion.amazon.com.mx | `A1AM78C64UM0Y8` |
| 阿联酋 | completion.amazon.ae | `A2VIGQ35RCS4UG` |

要点：

- **购买意图最强的词源**，直接反映消费者在电商里怎么搜
- 联想词里带 `for` / `with` / 容量 / 尺寸的居多，是选品和 listing 优化的金矿
- 前缀必须是完整词，`silicone w` 这种半截词会返回一堆无关结果

### 5. DuckDuckGo 联想词

```
GET https://duckduckgo.com/ac/?q={keyword}&type=list
```

返回：

```json
[{"phrase": "silicone water bottle"}, {"phrase": "silicone water bottle uk"}]
```

覆盖面不如 Google，但可作为第三来源交叉验证。

### 6. Reddit 讨论帖（话题来源，不是关键词）

```
GET https://www.reddit.com/search.json
    ?q={keyword}
    &limit=25
    &sort=relevance
    &t=year
```

返回标准 Reddit listing JSON，脚本提取：

```json
{"title": "Why does my silicone bottle taste like soap?",
 "subreddit": "CampingGear", "score": 412, "num_comments": 87,
 "url": "https://www.reddit.com/r/CampingGear/comments/..."}
```

要点：

- **这不是关键词源，是痛点源**。用它找「用户到底在抱怨什么」
- 高频痛点词直接变成 FAQ 和文章章节（`smell` / `leak` / `mold` / `taste` / `hard to clean`）
- 帖子标题本身就是极好的口语化长尾词，比联想词更真实
- 必须带 UA，否则 429

### 7. Google Trends（趋势与季节性）

没有公开 API。三种替代做法：

1. **WebFetch 抓 trends 页面**：`https://trends.google.com/trends/explore?q={kw}&geo=US`（需代理，返回 JS 渲染页，取数不稳定）
2. **pytrends 库**：`pip install pytrends`，可拿 interest_over_time / related_queries，需代理
3. **RSS 热搜**：`https://trends.google.com/trends/trendingsearches/daily/rss?geo=US`（只要当日热词，不做单关键词趋势）

**没有 Trends 数据时的判断法**：看联想词里是否出现季节词（`summer`、`christmas`、`back to school`、`black friday`），出现即说明有季节性，把文章排在高峰前 1–2 个月。

### 8. 其他可选平台

| 平台 | 接口 | 备注 |
|---|---|---|
| eBay | `https://autosug.ebay.com/autosug?kwd={kw}&sId=0&fmt=osr` | 返回 JSONP，需去壳 |
| Etsy | `https://www.etsy.com/suggestions_ajax.php?search_query={kw}` | 手作品类 |
| Walmart | `https://www.walmart.com/typeahead/v3/complete?term={kw}` | 北美零售 |
| Pinterest | `https://www.pinterest.com/resource/BaseSearchResource/get/` | 需构造复杂参数，不推荐 |
| TikTok | 无稳定公开接口 | 用 WebSearch 代替 |

---

## 三、代理配置

### 支持的形式

```bash
--proxy "http://127.0.0.1:7890"                    # 本地 Clash / V2Ray 的 http 端口
--proxy "http://user:pass@1.2.3.4:8080"            # 带认证
--proxy "socks5://user:pass@1.2.3.4:1080"          # 需要 pip install requests pysocks
```

### socks5 依赖

标准库不支持 socks5。脚本会明确报错并给出安装命令，不会静默失败：

```
socks5 代理需要额外依赖，请先执行：
  pip install requests pysocks
或改用 http 代理，例如 http://127.0.0.1:7890
```

**建议**：直接用 Clash / V2Ray 暴露的 **http 端口**（通常 7890），无需额外装包。

### 常见故障

| 现象 | 原因 | 处理 |
|---|---|---|
| `Tunnel connection failed: 502 Bad Gateway` | 代理未启动，或代理本身连不上目标 | 确认代理进程在跑；换节点 |
| `urlopen error timed out` | 无代理直连被墙 | 加 `--proxy` |
| Bing 返回空 | 缺 UA 头 | 用本脚本（已带 UA） |
| Amazon 返回空 | `prefix` 是半截词，或 `mid` 与 host 不匹配 | 检查站点对照表 |
| Reddit 429 | 请求过频 | 加大 `--delay`（如 2.0） |

---

## 四、无代理时的工作流（重要）

代理不是必需的。没有代理时按这个顺序做：

1. `--platforms bing,amazon` 跑脚本，拿到 100–200 个真实联想词
2. 用 `WebSearch` 工具补 6 类查询（见 SKILL.md Step 1 通道 B）
3. 用 `WebFetch` 抓 2–3 个排名靠前的竞品文章，从目录反推章节主题
4. 从 SERP 的 People Also Ask 提取疑问词

这样得到的词量通常足够支撑 8–12 篇文章的规划。**Google 的字母扩展词不是必需品**，它主要作用是发现冷门长尾。
