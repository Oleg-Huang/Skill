---
name: google-seo-market-keyword-analysis
version: 1.0.0
display_name: 谷歌SEO市场和关键词分析
display_name_en: Google SEO Market & Keyword Analysis
description: "谷歌SEO市场和关键词分析。从任意产品/品类出发，采集 Google、Bing、Amazon、Reddit、YouTube、DuckDuckGo、Google Trends 的真实搜索联想词与社区讨论，输出词族分类、搜索意图、KD 估算、A/B/C/D 优先级矩阵、话题清单与内容排期表。当用户提出「查关键词」「关键词热度」「关键词分析」「市场分析」「搜索热词」「选什么词」「做 SEO 规划」「内容排期」「找话题」「竞品关键词」「导出 excel 关键词」等需求时使用。"
description_en: "Google SEO market and keyword analysis. Starting from any product or category, collects real search suggestions and community discussions from Google, Bing, Amazon, Reddit, YouTube, DuckDuckGo and Google Trends, then outputs keyword families, search intent, KD estimates, an A/B/C/D priority matrix, a topic list and a content publishing schedule. Use when the user asks to research keywords, keyword volume, market analysis, search trends, which keywords to target, SEO planning, content calendars, topic ideas, competitor keywords, or to export keywords to Excel."
category: 效率 / 市场营销
tags: [SEO, 关键词研究, 谷歌SEO, 市场分析, 内容规划, 外贸]
agent_created: true
---

# 谷歌SEO市场和关键词分析

把「一个产品」变成「一张可直接执行的关键词作战地图」。

核心原则：**不编数据**。所有关键词必须来自真实联想词接口或真实 SERP，搜索量与 KD 一律标注为「估算区间」并写明推导依据，绝不假装是 Ahrefs 精确值。

## 适用场景

| 用户说 | 实际要做 |
|---|---|
| 查一下 XX 的关键词和热度 | 全流程：采集 → 分类 → 打分 → 表格 |
| 帮我做个 SEO 文章规划 | 关键词 → 话题聚类 → 12 个月排期 |
| 导出 Excel | 复用已有 JSON，只跑建表脚本 |
| 这个品类值不值得做 | 先跑市场判断（搜索量天花板 + 竞争格局），再决定是否深入 |

## 开工前必须问清 4 项

**这是硬性门槛，缺任何一项都不能开始采集。** 用 `AskUserQuestion` 一次性问完，不要分多轮。

### 1. 产品（必问）

要具体到「英文品类核心词」，不是中文概念。

- ❌ 错：「硅胶垫」——对应 trivet / placemat / mat 三个不重叠品类
- ✅ 对：「silicone trivet」（隔热垫）或「silicone placemat」（餐垫）

如果用户给的是中文宽泛词，先拆成 1–3 个英文候选词让用户确认，再往下走。**中英文品类经常不是一一对应**，这是最容易翻车的地方。

### 2. 目标市场 + 语言（必问）

决定 `gl` / `hl` / Amazon `mid` / Bing `mkt` 参数，直接改变结果。

常用组合：`US/en`、`UK/en`、`DE/de`、`AU/en`、`CA/en`、`JP/ja`、`全球/en`。

### 3. 代理（必问，不可跳过）

**这一项决定用哪条采集通道。**

先实测：Google / YouTube / DuckDuckGo / Reddit 的联想词接口在部分网络环境下会被拦截（返回 `502 Bad Gateway` 或超时）。Amazon 的 completion 接口通常可直连。

- **有代理** → 走 `scripts/collect_suggest.py`（支持 `http://` 与 `socks5://`），拿到原始联想词
- **无代理** → 走 `WebSearch` 工具（平台内置通道，不受本地网络影响），再用 SERP 结果反推词族

问法示例：

> 采集 Google / Reddit 联想词需要代理。你有可用的代理吗？（如 `http://127.0.0.1:7890` 或 `socks5://user:pass@ip:port`）没有的话我改用平台搜索通道，同样能出结果，但拿不到完整的字母扩展词。

### 4. 平台（多选）

让用户勾选，默认建议 Google + Amazon + Reddit。

| 平台 | 拿到什么 | 适用 |
|---|---|---|
| **Google** | 联想词、字母扩展（a–z）、疑问词 | 通用搜索需求，最核心 |
| **Bing** | 联想词 | Google 被墙时的替代；欧美 B2B 用户占比高 |
| **Amazon** | 电商搜索词（购买意图最强） | B2C、选品、listing 优化 |
| **Reddit** | 真实讨论帖标题、痛点、口语表达 | 找话题、找内容角度、找长尾 |
| **YouTube** | 视频搜索词 | 教程类、测评类内容选题 |
| **DuckDuckGo** | 联想词 | 补充覆盖，隐私向用户 |
| **Google Trends** | 趋势曲线、季节性 | 判断增长/衰退、定发布月份 |
| **Etsy / TikTok** | 手作、社媒热词 | 特定品类补充 |

## 工作流

### Step 1 — 采集原始词

**通道 A：脚本（有代理）**

```bash
python scripts/collect_suggest.py \
  --seed "silicone water bottle" \
  --market US --lang en \
  --platforms google,amazon,youtube,ddg,reddit \
  --proxy "http://127.0.0.1:7890" \
  --alphabet \
  --out keywords_raw.json
```

参数说明：

- `--seed` 可重复传多个，或用逗号分隔
- `--alphabet` 开启 a–z 字母扩展（26 次请求/词，量大但覆盖全）
- `--modifiers` 开启疑问/比较/购买修饰词扩展（`how/what/best/vs/for/cheap/wholesale`）
- 每个平台失败不影响其他平台，失败项写入 JSON 的 `errors`

**通道 B：无代理（用 WebSearch 工具）**

按以下顺序执行，每类至少 3 条查询：

1. 主词 + 品类词：`"silicone water bottle" best brands review 2026`
2. 对比词：`"silicone water bottle" vs plastic steel glass comparison`
3. 购买意图：`"silicone water bottle" price wholesale manufacturer supplier`
4. 疑问词：`"is silicone water bottle" safe BPA taste`
5. 社区：`site:reddit.com "silicone water bottle" problems smell`
6. 竞品 SERP：看前 10 名是谁（Amazon / 品牌站 / 平台页 / 博客）

从结果标题、摘要、People Also Ask、相关搜索里提取候选词。**不要凭记忆编词**。

### Step 2 — 清洗与归族

去掉：

- 品牌词（`big ass fan`、`hydro flask` 等）——单独列一节「品牌词，不做」，因为搜索者要买原厂或维修，转化不了
- 无关词（同名不同物，如 `trivet` 撞到人名/地名）
- 重复词、拼写变体（合并为一条，标注变体）

按**词族**归类。词族 = 搜索意图相同、SERP 高度重叠的一组词。一个词族对应一个页面，**不同词族必须拆页**。

典型词族结构：

```
核心品类词     silicone water bottle
属性限定词     bpa free / collapsible / with straw / 1 liter / insulated
场景词         for travel / for hiking / for kids / for gym
对比词         silicone vs plastic / vs stainless steel
问题词         is silicone safe / how to clean / does it leak
B2B 词         manufacturer / supplier / wholesale / OEM / custom / private label
```

### Step 3 — 标注意图与商业价值

每个词标注：

| 字段 | 取值 |
|---|---|
| 意图 | 信息型 / 商业调研 / 交易型 / 导航型 |
| 客群 | B2C / B2B / 两者 |
| 漏斗位置 | 认知 / 考虑 / 决策 |
| 是否值得做 | 是 / 观察 / 不做 |

判断要点：

- 带 `best` / `review` / `vs` → 商业调研，内容页主攻
- 带 `buy` / `price` / `near me` / `wholesale` → 交易型，产品页/询盘页主攻
- 带 `how` / `what` / `why` / `is` → 信息型，博客主攻，做流量入口
- 带品牌名 → 导航型，除非做对比文否则不碰

### Step 4 — 打分与优先级

按 `references/scoring-model.md` 的规则打分。核心是三条：

1. **搜索量估算**：不追求精确值，用「区间 + 依据」表达
2. **KD 启发式**：看 SERP 前 10 的构成，而不是查第三方分数
3. **优先级矩阵**：搜索量 × KD × 意图 → A/B/C/D

| 级别 | 定义 | 动作 |
|---|---|---|
| **A** | 中高量 + 低中 KD + 商业意图 | 立即写，排期前 3 个月 |
| **B** | 高量高 KD，或中量中 KD | 辅助文，蹭长尾 |
| **C** | 泛词、KD 高、意图杂 | 只做观察，不投人力 |
| **D** | 品牌词、无关词 | 明确不做 |

**制造商 / B2B 站点的通用规律**：`manufacturer` / `supplier` / `wholesale` / `OEM` / `custom` 这类词月搜索量往往只有 300–900，但 KD 常在 8–15，SERP 上多是 Made-in-China / Alibaba 平台页——独立站认真写一篇就能排上去，询盘质量远高于 B2C 泛词。**这类词优先级要给 A，不能因为量小就砍掉。**

### Step 5 — 话题聚类与内容排期

把关键词映射到「用户真实讨论的话题」，而不是生造标题。

- 有 Reddit 数据 → 直接用帖子标题里的高频痛点（`smell`、`leak`、`hard to clean`、`taste like plastic`）
- 无 Reddit 数据 → 从 SERP 的 People Also Ask + 竞品文章目录反推

每篇文章必须绑定：

```
标题 / URL slug / 主关键词 / 次关键词 / 搜索量 / KD / 字数 / 发布月份 / 季节触发点 / Schema 类型
```

季节触发点很重要：把文章排在搜索高峰**前 1–2 个月**发布，给 Google 留索引和爬坡时间。

### Step 6 — 产出

默认产出三件套，除非用户明确只要一种：

| 格式 | 用途 | 生成方式 |
|---|---|---|
| Markdown | 快速阅读、直接复制 | 直接写 |
| HTML | 可视化报告、给客户看 | 直接写（表格化、分章节） |
| Excel | 数据加工、筛选排序 | `scripts/build_excel.py` |

Excel 固定 3 个工作表：

1. **关键词总表** — 关键词 / 词族 / 月搜索量 / KD / 意图 / 客群 / 优先级 / 处理建议 / 备注，带筛选 + 冻结首行 + 优先级配色
2. **词族汇总** — 每族词数 / 搜索量合计 / 占比 / 平均 KD / A 级词数，用公式引用明细
3. **优先级策略** — A/B/C/D 四级执行建议 + B2B 投入说明

## 输出时必须说清的 4 件事

每次交付都在正文里明确写出来，不要让用户自己猜：

1. **数据来源**：用了哪几个平台、哪种通道（脚本 / WebSearch）、有没有代理
2. **数据性质**：搜索量是估算区间，不是 Ahrefs / Semrush 精确值；给出估算依据
3. **词族拆页建议**：哪几个词族不能放同一页，为什么
4. **下一步**：先写哪一篇、为什么是它

## 反面清单（这些做法会让结果失真）

- ❌ 把中文品类直译成英文就当关键词（`silicone heat pad` ≠ `trivet`）
- ❌ 一个页面同时打 `trivet` 和 `placemat`（主题不清，两边都排不上）
- ❌ 把品牌词算进主攻词（`big ass fan` 月搜 110K，但搜的人要维修不要新风扇）
- ❌ 编造精确搜索量（`22,340/月` 这种数字没有数据源就是假的）
- ❌ 只给词表不给排期（用户要的是能执行的东西）
- ❌ 忽略 B2B 长尾词（量小但转化最高，制造商站点的命脉）

## 参考文件

| 文件 | 何时读 |
|---|---|
| `references/platform-endpoints.md` | 写/改采集脚本时，查接口 URL、参数、返回格式、被墙情况 |
| `references/scoring-model.md` | Step 4 打分时，查搜索量区间、KD 启发式、优先级规则 |
| `references/output-spec.md` | Step 6 产出时，查三种格式的结构模板与配色规范 |
